define(function() {
    var konyLoggerModule = require('com/konymp/pdfviewer/konyLogger');
    var konymp = konymp || {};
    konymp.logger = (new konyLoggerModule("PDF Viewer Component")) || function() {};
    konymp.logger.setLogLevel("DEBUG");
    konymp.logger.enableServerLogging = true;
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {
          	konymp.logger.trace("----------Entering constructor Function---------", konymp.logger.FUNCTION_ENTRY);
            this._url = "";
          	this._googleBasicUrl = "https://docs.google.com/gview?embedded=true&url=";
          	this._urlRegex = /^(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)$/;
          	this._mimeType = "application/pdf";
          	this._iphonePath = "";
          	this._androidPath = "";
          	this._pdfType = "";
          	this._iphoneType = "pdf";
          	this.local = true;
          	this._urlError = {	"error":"Invalid Path","message":"please give a valid URL"};
          	this._pathError = {	"error":"Invalid Path","message":"please enter a valid path"};
          	this.type = {
              	"Online" : true,
              	"Local File Path" : false
            };
          	this._deviceName = kony.os.deviceInfo().name;
          	this._platformPdfFunctions = {
                "android": this.fetchAndDisplayPDFAndroid.bind(this)
            };
          	konymp.logger.trace("----------Exiting constructor ---------", konymp.logger.FUNCTION_EXIT);
        },
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {
          	konymp.logger.trace("----------Entering initGettersSetters Function---------", konymp.logger.FUNCTION_ENTRY);
            defineSetter(this, "url", function(val) {
              	try{
                  	this.validateUrl(val);
                }catch(exception){
              		konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
              		throw exception;
            	}
            });
            defineGetter(this, "url", function() {
              	try{
                  	return this._url;
                }catch(exception){
              		konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
              		throw exception;
            	}
            });
          	defineGetter(this, "setIphonePath", function() {
              	try{
                  	return this._iphonePath;
                }catch(exception){
              		konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
              		throw exception;
            	}
            });
            defineSetter(this, "setIphonePath", function(val) {
              	try{
                  	if(val !== undefined && val!== null && val !== "" || this.local ){
                  		this._iphonePath = val;
                	}else{
                  		throw this._urlError;
                	}
                }catch(exception){
              		konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
              		throw exception;
            	}
            });
          	defineGetter(this, "setAndroidPath", function() {
              	try{
                  	return this._androidPath;
                }catch(exception){
              		konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
              		throw exception;
            	}
            });
            defineSetter(this, "setAndroidPath", function(val) {
              	try{
                  	if(val !== undefined && val !== null && val !== "" || this.local){
                 	 	this._androidPath = val;
                	}
                }catch(exception){
              		konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
              		throw exception;
            	}
            });
          	defineGetter(this, "pdfType", function() {
              	try{
                  	return this._pdfType;
                }catch(exception){
              		konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
              		throw exception;
            	}
            });
            defineSetter(this, "pdfType", function(val) {
              	try{
                  	this._pdfType = val;
              		this.local = this.type[val];
                }catch(exception){
              		konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
              		throw exception;
            	}
            });
          	konymp.logger.trace("----------Exiting initsetgetter ---------", konymp.logger.FUNCTION_EXIT);
        },
      	/**
         * @function validateUrl
         * @description This function is used to validate url
         * @private
         * @param val
         */
      	validateUrl : function(val){
          	try{
              	konymp.logger.trace("----------Entering validateUrl Function---------", konymp.logger.FUNCTION_ENTRY);
              	var extenstion = val.substring(val.length-3,val.length).toLowerCase();
              	if(val !== null && this._urlRegex.test(val) && extenstion !== null && extenstion.endsWith("pdf")){
                  	this._url = val;
                }
              	else{
                  	throw this._urlError;
                }
              	konymp.logger.trace("----------Exiting validateUrl ---------", konymp.logger.FUNCTION_EXIT);
            }catch(exception){
              	konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
              	throw exception;
            }
        },
      	platformCall : function(eventObj){
          	try{
              	this._platformPdfFunctions[this._deviceName](eventObj);
            }catch(exception){
              	konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
              	throw exception;
            }
        },
        /**
         * @function fetchAndDisplayPDFAndroid
         * @description This function is used to render pdf in android
         * @private
         * @param eventObj
         */
        fetchAndDisplayPDFAndroid: function(eventObj) {
            try {
              	if(eventObj !== undefined && eventObj !== null){
              		konymp.logger.trace("----------Entering fetchAndDisplayPDFAndroid Function---------", konymp.logger.FUNCTION_ENTRY);
              		var konyMain = java.import('com.konylabs.android.KonyMain');
              		var context = konyMain.getActivityContext();
              		if(this.local){
                		var webview = java.import("android.webkit.WebView");
                		var viewGroup = java.import("android.view.ViewGroup");
                		var wvClient = java.import("android.webkit.WebViewClient");
                		var webViewObject = new webview(context);
                		var layoutParams = viewGroup.LayoutParams;
                		webViewObject.getSettings().setAllowFileAccessFromFileURLs(true);
                		webViewObject.getSettings().setJavaScriptEnabled(true);
                      	webViewObject.getSettings().setBuiltInZoomControls(true);
                		var konyDeviceInfoObject = kony.os.deviceInfo();
                		var layoutParamsObject = new layoutParams(konyDeviceInfoObject.deviceWidth, konyDeviceInfoObject.deviceHeight);
                		webViewObject.setLayoutParams(layoutParamsObject);
                		webViewObject.setWebViewClient(new wvClient());
                		var url = this._googleBasicUrl  + this.url;
                		webViewObject.loadUrl(url);
                		eventObj.addView(webViewObject);
                		this.view.forceLayout();
	                }
    	          	else{
                      	var val = this._androidPath;
                      	var extenstion = val.substring(val.length-3,val.length).toLowerCase();
                  		if(extenstion.endsWith("pdf")){
                      		this._androidPath = val;
                    	}
                  		else{
                      		throw this._pathError;
                    	}
                  		var intent = java.import("android.content.Intent");
                  		var file = java.import("java.io.File");
                  		var Uri = java.import("android.net.Uri");
                  		var sendIntent = new intent(intent.ACTION_VIEW);
						sendIntent.addFlags(intent.FLAG_GRANT_READ_URI_PERMISSION);					                  	
        				sendIntent.setDataAndType(Uri.fromFile(new file(this._androidPath)),this._mimeType);
                  		context.startActivity(sendIntent);
                	}
              		konymp.logger.trace("----------Exiting fetchAndDisplayForAndroid ---------", konymp.logger.FUNCTION_EXIT);
                }
            } catch (exception) {
                konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
              	throw exception;
            }
        },
        /**
         * @function fetchAndDisplayPDFiOS
         * @description This function is used to render pdf in iOS
         * @private
         * @param uiviewObj
         */
        fetchAndDisplayPDFiOS: function(uiviewObj) {
            try {
              	if(uiviewObj !== undefined && uiviewObj !== null){
              		konymp.logger.trace("----------Entering fetchAndDisplayPDFIos Function---------", konymp.logger.FUNCTION_ENTRY);
                	var uIWebView = objc.import("UIWebView");
                	var nSURLObj = objc.import("NSURL");
                	var nSURLRequestObj = objc.import("NSURLRequest");
                	var urlRequestObj = nSURLRequestObj.alloc().jsinit();
                	var webViewObject = uIWebView.alloc().jsinit();
                	var width = uiviewObj.bounds.width;
                	var height = uiviewObj.bounds.height;
                	var frameVal = {
                    	"x": 0,
                    	"y": 0,
                    	"width": width,
                    	"height": height
                	};
                	webViewObject.frame = frameVal;
                  	webViewObject.scalesPageToFit = true;
              		if(this.local){
	                  	if(this._url !== undefined && this._url !== null && this._url !== ""){
    	                  	var urlObj = nSURLObj.alloc().initWithString(this._url);
                			urlRequestObj = nSURLRequestObj.requestWithURL(urlObj);
                			webViewObject.loadRequest(urlRequestObj);
                    	}
                		else{
	                      	throw this._urlError;
                    	}
                	}
              		else{
                  		if(this._iphonePath.startsWith("file://")){
                      		var path = this._iphonePath.replace("file://", "");
                      		var urlPath = nSURLObj.alloc().initWithString(path);
                      		webViewObject.loadRequest(nSURLRequestObj.requestWithURL(urlPath));
                    	}
                  		else if(this._iphonePath.startsWith("/")){
                      		var nSFileManager = objc.import("NSFileManager");
                      		var nsFileManager = nSFileManager.alloc().jsinit();
                      		if(nsFileManager.fileExistsAtPath(this._iphonePath)){
                          		var urlPath1 = nSURLObj.alloc().initWithString(this._iphonePath);
                          		webViewObject.loadRequest(nSURLRequestObj.requestWithURL(urlPath1));
                        	}
                      		else{
                          		throw {"Error": "Invalid Path","message":"The file path you given doesn't existes"};
                        	}
                    	}
                  		else{
                      		if(this._iphonePath.charAt(".") !== -1){
                          		var nSBundle = objc.import("NSBundle");
                  				var filePath = nSBundle.mainBundle().pathForResourceOfType(this._iphonePath, this._iphoneType);
                  				var urlPath2 = nSURLObj.alloc().initWithString(filePath);
                          		webViewObject.loadRequest(nSURLRequestObj.requestWithURL(urlPath2));
                        	}
                      		else{
                          		throw this._pathError;
                        	}
                    	}
                	}
                	uiviewObj.addSubview(webViewObject);
                	this.view.forceLayout();
              		konymp.logger.trace("----------Exiting FetchAndDisplayForIos ---------", konymp.logger.FUNCTION_EXIT);
                }
            } catch (exception) {
                konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
              	throw exception;
            }
        },
        /**
         * @function setURL
         * @description Function used to change URL of the pdf dynamically
         * @public
         * @param url
         */
        setURL: function(url) {
          	try{
              	konymp.logger.trace("----------Entering setURL Function---------", konymp.logger.FUNCTION_ENTRY);
            	if(url !== undefined && url !== null && url !== ""){
            		this._url = url; 
              		this.local = true;
              		this.renderWebView();
            	}
            	else{
              		throw this._urlError;
            	}
              	konymp.logger.trace("----------Exiting setUrl ---------", konymp.logger.FUNCTION_EXIT);
            }
          	catch(exception){
              	konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
              	throw exception;
            }
        },
      	setAndroidFilePath : function(path){
          	try{
              	konymp.logger.trace("----------Entering setAndroidFilePath Function---------", konymp.logger.FUNCTION_ENTRY);
          		if(path !== undefined && path !== null && path !== ""){
            		this._androidPath = path;
              		this.local = false;
              		this.renderWebView();
            	}
            	else{
              		throw this._pathError;
            	}
              	konymp.logger.trace("----------Exiting setAndroidFilePath ---------", konymp.logger.FUNCTION_EXIT);
            }
          	catch(exception){
              	konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
              	throw exception;
            }
        },
      	setIphoneFilePath : function(path){
          	try{
              	konymp.logger.trace("----------Entering setIphoneFilePath Function---------", konymp.logger.FUNCTION_ENTRY);
          		if(path !== undefined && path !== null && path !== ""){
            		this._iphonePath = path; 
              		this.local = false;
              		this.renderWebView();
            	}
            	else{
              		throw this._pathError;
            	}
              	konymp.logger.trace("----------Exiting setIphoneFilePath ---------", konymp.logger.FUNCTION_EXIT);
            }
          	catch(exception){
              	konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
              	throw exception;
            }
        },
      	renderWebView : function(){
          	try{
              	konymp.logger.trace("----------Entering renderWebview Function---------", konymp.logger.FUNCTION_ENTRY);
          		if (this.view.nativePDF) {
                	this.view.remove(this.view.nativePDF);
            	}
          		var nativePDF = new kony.ui.NativeContainer({
                	"height": "100%",
                	"id": "nativePDF",
                	"isVisible": true,
	                "left": "0%",
                	"onCreated": this.platformCall.bind(this),
                	"onLayoutSubviews": this.fetchAndDisplayPDFiOS.bind(this),
                	"top": "0%",
                	"width": "100%",
                	"zIndex": 1
            	}, {}, {});
            	this.view.add(nativePDF);
              	konymp.logger.trace("----------Exiting renderWebview ---------", konymp.logger.FUNCTION_EXIT);
        	}
          	catch(exception){
              	konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
              	throw exception;
            }
        }
    };
});