define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_NativeContainer_g05d70ecdd1f4bfbb89c0271a6ef58b2: function AS_NativeContainer_g05d70ecdd1f4bfbb89c0271a6ef58b2(eventobject) {
        var self = this;
        this.platformCall(eventobject);
    },
    AS_NativeContainer_gd74898a6e584552961c05116382c748: function AS_NativeContainer_gd74898a6e584552961c05116382c748(eventobject) {
        var self = this;
        this.fetchAndDisplayPDFiOS(eventobject);
    }
});