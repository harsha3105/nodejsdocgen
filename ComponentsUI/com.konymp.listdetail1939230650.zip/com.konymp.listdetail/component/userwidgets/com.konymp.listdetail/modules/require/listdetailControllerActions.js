define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnBack **/
    AS_Button_gacf69f11c4d49dc865b12d619545ac7: function AS_Button_gacf69f11c4d49dc865b12d619545ac7(eventobject) {
        var self = this;
        this._segClickFlag = 0;
        this.navigateFlex(this, "100%");
        this.reanimateTheWidgetsInDetailsPage();
        this.view.forceLayout();
    },
    /** onClick defined for flxDetailsHeader **/
    AS_FlexContainer_e8eacf497d014a869b4bc5127c5ca629: function AS_FlexContainer_e8eacf497d014a869b4bc5127c5ca629(eventobject) {
        var self = this;
        //alert();
    },
    /** onClick defined for flxMobileImageHolder **/
    AS_FlexContainer_e9f18a5b1c164cb2a658ac1276515040: function AS_FlexContainer_e9f18a5b1c164cb2a658ac1276515040(eventobject) {
        var self = this;
        this.onClickOfCallFlex(this.view.lblCallMobileValue.text);
    },
    /** onClick defined for flxWorkImageHolder **/
    AS_FlexContainer_acf4022b9656467b950658802b03dc81: function AS_FlexContainer_acf4022b9656467b950658802b03dc81(eventobject) {
        var self = this;
        this.onClickOfCallFlex(this.view.lblCallWorkValue.text);
    },
    /** onClick defined for flxEmailHolder **/
    AS_FlexContainer_i4f3ad06dbd346f4ab110b621c37d322: function AS_FlexContainer_i4f3ad06dbd346f4ab110b621c37d322(eventobject) {
        var self = this;
        this.onClickOfEmailFlex();
    },
    /** onRowClick defined for segEmployees **/
    AS_Segment_feaf4d19ded34c0ea57266096d9945a9: function AS_Segment_feaf4d19ded34c0ea57266096d9945a9(eventobject, sectionNumber, rowNumber) {
        var self = this;
        if (this._segClickFlag == 0) {
            this._segClickFlag = 1;
            this.navigateFlex(this, "0%");
            this.setGestureForScrollingAnimationInDetailsPage();
            this.view.forceLayout();
        }
    },
    /** onTouchMove defined for segEmployees **/
    AS_Segment_b109dcef159046b187f83e2c78fddfab: function AS_Segment_b109dcef159046b187f83e2c78fddfab(eventobject, x, y) {
        var self = this;
        this.getScrolledSection();
    },
    /** onTouchEnd defined for segEmployees **/
    AS_Segment_ebcc21eb5a4a48c9b9d30071b4461839: function AS_Segment_ebcc21eb5a4a48c9b9d30071b4461839(eventobject, x, y) {
        var self = this;
        this.getScrolledSection();
    },
    /** onClick defined for A **/
    AS_Button_f81abe2f93ac412aab46b47f027d30c1: function AS_Button_f81abe2f93ac412aab46b47f027d30c1(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.A);
    },
    /** onClick defined for B **/
    AS_Button_i06481a655f846848217b3db8f37dd63: function AS_Button_i06481a655f846848217b3db8f37dd63(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.B);
    },
    /** onClick defined for C **/
    AS_Button_i9fbc65d6f9a4e0c93de31af854552c1: function AS_Button_i9fbc65d6f9a4e0c93de31af854552c1(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.C);
    },
    /** onClick defined for D **/
    AS_Button_a66c07e6344148e388d89ca3da3f7ff9: function AS_Button_a66c07e6344148e388d89ca3da3f7ff9(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.D);
    },
    /** onClick defined for E **/
    AS_Button_d476330db9cf4daabd88301e9ed407d6: function AS_Button_d476330db9cf4daabd88301e9ed407d6(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.E);
    },
    /** onClick defined for F **/
    AS_Button_c208f9f851314e9295825367f25db91f: function AS_Button_c208f9f851314e9295825367f25db91f(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.F);
    },
    /** onClick defined for G **/
    AS_Button_hc59d71492ab475c8804bdb8d34fc3fa: function AS_Button_hc59d71492ab475c8804bdb8d34fc3fa(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.G);
    },
    /** onClick defined for H **/
    AS_Button_f54883a5a2264c9ea08a9a81e074482f: function AS_Button_f54883a5a2264c9ea08a9a81e074482f(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.H);
    },
    /** onClick defined for I **/
    AS_Button_a2b948b0498c449aac3bdf1deb3fc9d5: function AS_Button_a2b948b0498c449aac3bdf1deb3fc9d5(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.I);
    },
    /** onClick defined for J **/
    AS_Button_c03e4b9148eb4768bc7e7824a6768244: function AS_Button_c03e4b9148eb4768bc7e7824a6768244(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.J);
    },
    /** onClick defined for K **/
    AS_Button_f79c0dfa3e6144838ddb2692a8c97e44: function AS_Button_f79c0dfa3e6144838ddb2692a8c97e44(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.K);
    },
    /** onClick defined for L **/
    AS_Button_d13fc8bfa1ca4d3eb1beab014d0af5f8: function AS_Button_d13fc8bfa1ca4d3eb1beab014d0af5f8(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.L);
    },
    /** onClick defined for M **/
    AS_Button_b31b196da37a448badc4b0bb9d2cfd19: function AS_Button_b31b196da37a448badc4b0bb9d2cfd19(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.M);
    },
    /** onClick defined for N **/
    AS_Button_ib7542cf2c4b4e3cad142df82e688c0f: function AS_Button_ib7542cf2c4b4e3cad142df82e688c0f(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.N);
    },
    /** onClick defined for O **/
    AS_Button_ha5f060699b34577ac6f8dce0e87a798: function AS_Button_ha5f060699b34577ac6f8dce0e87a798(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.O);
    },
    /** onClick defined for P **/
    AS_Button_f9d85744ce7f4096985bba001ac9a27b: function AS_Button_f9d85744ce7f4096985bba001ac9a27b(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.P);
    },
    /** onClick defined for Q **/
    AS_Button_g1badb11ad21419eb5952e92593f0ed7: function AS_Button_g1badb11ad21419eb5952e92593f0ed7(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.Q);
    },
    /** onClick defined for R **/
    AS_Button_ff8addec62364d9293481999f3e892b0: function AS_Button_ff8addec62364d9293481999f3e892b0(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.R);
    },
    /** onClick defined for S **/
    AS_Button_ab0c3de90c7746fb82a46a92742d632d: function AS_Button_ab0c3de90c7746fb82a46a92742d632d(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.S);
    },
    /** onClick defined for T **/
    AS_Button_gdb3c93a75544e3bbcc8b0560462da65: function AS_Button_gdb3c93a75544e3bbcc8b0560462da65(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.T);
    },
    /** onClick defined for U **/
    AS_Button_cdeaa44886a44fd3994e34b563bcd868: function AS_Button_cdeaa44886a44fd3994e34b563bcd868(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.U);
    },
    /** onClick defined for V **/
    AS_Button_b9f4a0b622b7445ba4cae0de8de8b274: function AS_Button_b9f4a0b622b7445ba4cae0de8de8b274(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.V);
    },
    /** onClick defined for W **/
    AS_Button_i2bf3089ebe8492394f1574a048ec17e: function AS_Button_i2bf3089ebe8492394f1574a048ec17e(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.W);
    },
    /** onClick defined for X **/
    AS_Button_ab6ad6046c794477bf39a0fabf436874: function AS_Button_ab6ad6046c794477bf39a0fabf436874(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.X);
    },
    /** onClick defined for Y **/
    AS_Button_c5ee9a0c7b63450c91f95b8e49c2c929: function AS_Button_c5ee9a0c7b63450c91f95b8e49c2c929(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.Y);
    },
    /** onClick defined for Z **/
    AS_Button_ja605b7fd5f24a0f8874fe8626753e26: function AS_Button_ja605b7fd5f24a0f8874fe8626753e26(eventobject) {
        var self = this;
        this.scrollSegmentToSelectedAlphabetIndex(this.view.Z);
    },
    /** onTouchMove defined for flxDictionary **/
    AS_FlexContainer_d4d4860de4534e04bc60477e92369e57: function AS_FlexContainer_d4d4860de4534e04bc60477e92369e57(eventobject, x, y) {
        var self = this;
        this.onTouchScrollMove(eventobject, x, y);
    },
    /** onTouchEnd defined for flxDictionary **/
    AS_FlexContainer_c2ca92b3b7ce4f23bca4a08746ab875c: function AS_FlexContainer_c2ca92b3b7ce4f23bca4a08746ab875c(eventobject, x, y) {
        var self = this;
        this.view.lblDisplaySelectedIndex.isVisible = false;
        this.view.forceLayout();
    },
    /** onTextChange defined for tbxSearch **/
    AS_TextField_hcd25907c3e04cad87f1e1c1390b5e98: function AS_TextField_hcd25907c3e04cad87f1e1c1390b5e98(eventobject, changedtext) {
        var self = this;
        this.onTextChangeAndDoneOfTbxSearch();
    },
    /** onDone defined for tbxSearch **/
    AS_TextField_jfa70935b4a144d98ad289b16b430b9b: function AS_TextField_jfa70935b4a144d98ad289b16b430b9b(eventobject, changedtext) {
        var self = this;
        this.onTextChangeAndDoneOfTbxSearch();
    },
    /** onTouchStart defined for tbxSearch **/
    AS_TextField_f5acbae24da54338aedcc6ebc18c150f: function AS_TextField_f5acbae24da54338aedcc6ebc18c150f(eventobject, x, y) {
        var self = this;
        this.onTouchStartOfTbxSearch();
    },
    /** onClick defined for btnSearchCancel **/
    AS_Button_i1dcbfe09be14023ab3d25e5dce6e1f6: function AS_Button_i1dcbfe09be14023ab3d25e5dce6e1f6(eventobject) {
        var self = this;
        this.onClickOfBtnCancelSearch();
    },
    /** preShow defined for listdetail **/
    AS_FlexContainer_a65ab0389c814290a028a275e595c7f0: function AS_FlexContainer_a65ab0389c814290a028a275e595c7f0(eventobject) {
        var self = this;
        this.view.segEmployees.setData([]);
    },
    /** postShow defined for listdetail **/
    AS_FlexContainer_b98f3b76d4ac41b38775b14e18ba768e: function AS_FlexContainer_b98f3b76d4ac41b38775b14e18ba768e(eventobject) {
        var self = this;
        this.fetchAllDetails();
    }
});