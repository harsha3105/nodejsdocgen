define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_TextField_65b85cf5d7e548019b4c31f30a5841b5: function AS_TextField_65b85cf5d7e548019b4c31f30a5841b5(eventobject, changedtext) {
        var self = this;
        this.onDoneCredentials(this.view.lblUsername);
    },
    AS_TextField_8eac0215d1ab4f9e89ce5a9507b0aaef: function AS_TextField_8eac0215d1ab4f9e89ce5a9507b0aaef(eventobject, changedtext) {
        var self = this;
        this.onDoneCredentials(this.view.lblPassword);
    },
    AS_FlexContainer_7278fc6cd3c049399803102a0be3bbe9: function AS_FlexContainer_7278fc6cd3c049399803102a0be3bbe9(eventobject) {
        var self = this;
        this.remembermeSelection();
    },
    AS_Button_4938413b5cd44a87bc918490e6f94e79: function AS_Button_4938413b5cd44a87bc918490e6f94e79(eventobject) {
        var self = this;
        this.invokeButtonClick();
    },
    AS_FlexContainer_2416c525aa74449b8ce12b31816e2c8d: function AS_FlexContainer_2416c525aa74449b8ce12b31816e2c8d(eventobject) {
        var self = this;
        if (this.view.lblUsername.top == "6%") {
            this.view.flxLblUsername.isVisible = false;
            this.invokeTouch(this.view.lblUsername, "-1%");
        }
        this.view.forceLayout();
    },
    AS_FlexContainer_0b131b5fe5b34d4bb58124d40674bc86: function AS_FlexContainer_0b131b5fe5b34d4bb58124d40674bc86(eventobject) {
        var self = this;
        if (this.view.lblPassword.top == "23%") {
            this.view.flxLblPassword.isVisible = false;
            this.invokeTouch(this.view.lblPassword, "16%");
        }
        this.view.forceLayout();
    }
});