define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Map_i1f07d1447eb4687a71060f5b47f5e9b: function AS_Map_i1f07d1447eb4687a71060f5b47f5e9b(eventobject, location) {
        var self = this;
        this.pinClicked(location);
    },
    AS_FlexContainer_b60d80d1b80546d68ea637a07334451f: function AS_FlexContainer_b60d80d1b80546d68ea637a07334451f(eventobject) {
        var self = this;
        this.searchThisArea();
    },
    AS_Segment_bc81a1cfe966423fb42670f49b2f9c86: function AS_Segment_bc81a1cfe966423fb42670f49b2f9c86(eventobject, sectionNumber, rowNumber) {
        var self = this;
        this.placeSelected(rowNumber);
    },
    AS_Segment_d5bcd655b00446a7b923828867e6e215: function AS_Segment_d5bcd655b00446a7b923828867e6e215(seguiWidget, sectionIndex, rowIndex) {
        var self = this;
        this.changeselectedMapPin(rowIndex);
    },
    AS_Button_jca4f53738964532b3d54cb7a2fcabeb: function AS_Button_jca4f53738964532b3d54cb7a2fcabeb(eventobject) {
        var self = this;
        this.openAppleMaps();
    },
    AS_Button_ifde78509a734e2dbcc2c0ed6f091ca2: function AS_Button_ifde78509a734e2dbcc2c0ed6f091ca2(eventobject) {
        var self = this;
        this.openGoogleMaps();
    },
    AS_Button_de7fb28826cf4b04b3fcc2adfa5de697: function AS_Button_de7fb28826cf4b04b3fcc2adfa5de697(eventobject) {
        var self = this;
        this.cancelDirections();
    },
    AS_Segment_ccd12039e9484ce6b1c9b49a586fd24e: function AS_Segment_ccd12039e9484ce6b1c9b49a586fd24e(eventobject, sectionNumber, rowNumber) {
        var self = this;
        this.placeSelected(rowNumber);
    },
    AS_Segment_g7b2863fdcb34044af7261f0603759da: function AS_Segment_g7b2863fdcb34044af7261f0603759da(eventobject) {
        var self = this;
        if (this.onPushOfSegment != null && this.onPushOfSegment != undefined) {
            kony.application.showLoadingScreen("", "", constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true, {});
            this.onPushOfSegment();
        }
    },
    AS_Segment_g7265778e4ae47508609ae0db722b9eb: function AS_Segment_g7265778e4ae47508609ae0db722b9eb(eventobject) {
        var self = this;
        this.view.segListView.height = "88%";
        this.view.segListView.selectedRowIndex = [0, this.view.segListView.data.length - 1];
        this.view.forceLayout();
    },
    AS_Segment_d2860d1168ac46e5b0a0058b15cee625: function AS_Segment_d2860d1168ac46e5b0a0058b15cee625(eventobject, x, y) {
        var self = this;
        this.initialDirectionPosition = parseInt(y);
    },
    AS_Segment_a68493c65e584978a6f1d2dbf2749f29: function AS_Segment_a68493c65e584978a6f1d2dbf2749f29(eventobject, x, y) {
        var self = this;
        if (parseInt(y) - this.initialDirectionPosition > 0) {
            if (this.view.segListView.height == "88%") {
                this.view.segListView.height = "100%";
            }
            this.view.forceLayout();
        }
    }
});