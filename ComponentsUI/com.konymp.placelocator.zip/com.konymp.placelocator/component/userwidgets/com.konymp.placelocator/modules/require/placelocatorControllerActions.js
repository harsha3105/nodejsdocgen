define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_FlexContainer_a5ef4136774245c998c0f733e6994b18: function AS_FlexContainer_a5ef4136774245c998c0f733e6994b18(eventobject) {
        var self = this;
        this.changeOfLocationStart();
    },
    AS_Button_h47883485f284b7398c0bd4f4b8a581e: function AS_Button_h47883485f284b7398c0bd4f4b8a581e(eventobject) {
        var self = this;
        this.closeRoutes();
    },
    AS_FlexContainer_d9739c2b70c4432fb79d4564f98fb634: function AS_FlexContainer_d9739c2b70c4432fb79d4564f98fb634(eventobject) {
        var self = this;
        kony.print("** Dummy action to make the actions of the below flex unaccessable **");
    },
    AS_Segment_ebd61fae8dd649ecac382e2286a41efb: function AS_Segment_ebd61fae8dd649ecac382e2286a41efb(eventobject, sectionNumber, rowNumber) {
        var self = this;
        this.recentSearchItemSeleceted();
    },
    AS_UWI_b412f0c212d641fd82d925412efe7996: function AS_UWI_b412f0c212d641fd82d925412efe7996() {
        var self = this;
        this.loadMoreNearbyPlaces();
    },
    AS_Image_gffdade6b75245f6b8a1b5fe2e65a227: function AS_Image_gffdade6b75245f6b8a1b5fe2e65a227(eventobject, x, y) {
        var self = this;
        this.viewShift();
    },
    AS_Image_a4aece6ddc134609a627e4248c8d58bd: function AS_Image_a4aece6ddc134609a627e4248c8d58bd(eventobject, x, y) {
        var self = this;
        this.enableFilterView();
    },
    AS_Label_a7da1ba1d8d74df8a9c3441a91898509: function AS_Label_a7da1ba1d8d74df8a9c3441a91898509(eventobject, x, y) {
        var self = this;
        this.viewShift();
    },
    AS_Label_d429eb6e26254302a6bff4ddbc5933b1: function AS_Label_d429eb6e26254302a6bff4ddbc5933b1(eventobject, x, y) {
        var self = this;
        this.enableFilterView();
    },
    AS_FlexContainer_d212826943a34b24bbf2f72aea6405b7: function AS_FlexContainer_d212826943a34b24bbf2f72aea6405b7(eventobject) {
        var self = this;
        this.clearSelectedFilterOptions();
    },
    AS_FlexContainer_i7b83802d9a842fabe2ef7d82b603f54: function AS_FlexContainer_i7b83802d9a842fabe2ef7d82b603f54(eventobject) {
        var self = this;
        this.createDynamicMenu(null);
    }
});