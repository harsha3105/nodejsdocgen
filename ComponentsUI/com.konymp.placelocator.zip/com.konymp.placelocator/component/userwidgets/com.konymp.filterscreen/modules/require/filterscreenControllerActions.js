define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Label_db16b1af810f4434ab0ffb9ea7c85236: function AS_Label_db16b1af810f4434ab0ffb9ea7c85236(eventobject, x, y) {
        var self = this;
        this.applyFilter();
    },
    AS_Label_b2718babf6d74b94a8c41b05324562bc: function AS_Label_b2718babf6d74b94a8c41b05324562bc(eventobject, x, y) {
        var self = this;
        this.priceFilter(eventobject);
    },
    AS_Label_cbac5a461fe341b187814d2cca9326b3: function AS_Label_cbac5a461fe341b187814d2cca9326b3(eventobject, x, y) {
        var self = this;
        this.priceFilter(eventobject);
    },
    AS_Label_e7b0d5978b1340b2ba8af5a56ad87fac: function AS_Label_e7b0d5978b1340b2ba8af5a56ad87fac(eventobject, x, y) {
        var self = this;
        this.priceFilter(eventobject);
    },
    AS_Label_aa5a58edaf5e4846944153a2bd4fb897: function AS_Label_aa5a58edaf5e4846944153a2bd4fb897(eventobject, x, y) {
        var self = this;
        this.changeSortSelection(eventobject);
    },
    AS_Label_cc60273d45fb4e54957883ca5dad8ca7: function AS_Label_cc60273d45fb4e54957883ca5dad8ca7(eventobject, x, y) {
        var self = this;
        this.changeSortSelection(eventobject);
    },
    AS_Label_e34e26904cbc4cc7bdc8e1e834d5a14f: function AS_Label_e34e26904cbc4cc7bdc8e1e834d5a14f(eventobject, x, y) {
        var self = this;
        this.changeSortSelection(eventobject);
    },
    AS_Label_d4374c0530964a08b65adf1f5af886b8: function AS_Label_d4374c0530964a08b65adf1f5af886b8(eventobject, x, y) {
        var self = this;
        this.changeSortSelection(eventobject);
    },
    AS_Image_g222167ec5f14be3824778b4305cc61b: function AS_Image_g222167ec5f14be3824778b4305cc61b(eventobject, x, y) {
        var self = this;
        this.starRating(eventobject);
    },
    AS_Image_f5b484deab4a47038779c10e1da70197: function AS_Image_f5b484deab4a47038779c10e1da70197(eventobject, x, y) {
        var self = this;
        this.starRating(eventobject);
    },
    AS_FlexContainer_i3302339aef14689a25c260e68e47053: function AS_FlexContainer_i3302339aef14689a25c260e68e47053(eventobject) {
        var self = this;
        this.toggleOpenClose(eventobject);
    },
    AS_Label_jb1f38ab004744619112ff5948e58cd6: function AS_Label_jb1f38ab004744619112ff5948e58cd6(eventobject, x, y) {
        var self = this;
        this.resetFilters();
    },
    AS_Label_d80125d3840741199542c0f892588abc: function AS_Label_d80125d3840741199542c0f892588abc(eventobject, x, y) {
        var self = this;
        this.priceFilter(eventobject);
    },
    AS_FlexContainer_cffcc6c473ad41f38f2fb56677fd1487: function AS_FlexContainer_cffcc6c473ad41f38f2fb56677fd1487(eventobject) {
        var self = this;
        //No Action to be performed
    }
});