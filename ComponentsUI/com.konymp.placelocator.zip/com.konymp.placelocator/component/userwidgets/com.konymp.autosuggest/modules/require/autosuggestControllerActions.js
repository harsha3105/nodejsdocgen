define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Segment_a5448d2738c2400d96e68aa9b3068763: function AS_Segment_a5448d2738c2400d96e68aa9b3068763(eventobject, sectionNumber, rowNumber) {
        var self = this;
        this.dataSelected(rowNumber);
    },
    AS_FlexContainer_b10e16a5303c48e3ac77a4ec7e3bb0ee: function AS_FlexContainer_b10e16a5303c48e3ac77a4ec7e3bb0ee(eventobject) {
        var self = this;
        this.currentLocationSelected();
    }
});