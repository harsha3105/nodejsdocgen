define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Image_e864a31e650140638d0a2969c9a5b713: function AS_Image_e864a31e650140638d0a2969c9a5b713(eventobject, x, y) {
        var self = this;
        this.changeSelectedAndUnselectedImage(eventobject);
    },
    AS_Image_e2d8bc8d33a2427284f4282e57e41544: function AS_Image_e2d8bc8d33a2427284f4282e57e41544(eventobject, x, y) {
        var self = this;
        this.changeSelectedAndUnselectedImage(eventobject);
    },
    AS_Image_gbca0559edc7419da97cd4703e2d8c4b: function AS_Image_gbca0559edc7419da97cd4703e2d8c4b(eventobject, x, y) {
        var self = this;
        this.changeSelectedAndUnselectedImage(eventobject);
    },
    AS_Image_afd2ea559c05480aaa4653865e41848b: function AS_Image_afd2ea559c05480aaa4653865e41848b(eventobject, x, y) {
        var self = this;
        this.changeSelectedAndUnselectedImage(eventobject);
    },
    AS_Image_ead3570a5de740dba70737923bca8c1a: function AS_Image_ead3570a5de740dba70737923bca8c1a(eventobject, x, y) {
        var self = this;
        this.changeSelectedAndUnselectedImage(eventobject);
    },
    AS_Image_ca40ece32cf54154a149326e0f342734: function AS_Image_ca40ece32cf54154a149326e0f342734(eventobject, x, y) {
        var self = this;
        this.changeSelectedAndUnselectedImage(eventobject);
    },
    AS_Image_b3b2ff2d44d04190b2c8cedff1c34d5a: function AS_Image_b3b2ff2d44d04190b2c8cedff1c34d5a(eventobject, x, y) {
        var self = this;
        this.changeSelectedAndUnselectedImage(eventobject);
    }
});