/*
#
#  Created by Team Kony.
#  Copyright (c) 2017 Kony Inc. All rights reserved.
#
*/ 
define(function() {
  var konyLoggerModule = require('com/konymp/ratingprompt/KonyLogger');
  var konymp = konymp || {};
  konymp.logger = new konyLoggerModule("Rating Prompt");
  return {
    constructor: function(baseConfig, layoutConfig, pspConfig) {
      this._page = {
        RATING: 1,
        FEEDBACK: 2,
        THANKYOU: 3
      };
      this.seed = Math.random();
      this._timerId="com.konymp.ratingPromptTimer.timerId"+this.random();
      this._feedbackPopup = null;
      this._rateDesc = null;
      this._completionDesc = null;
      this.currentPage = null;
      this._rateTitle = null;
      this._inactiveStar=this.unselectedRatingImageSrc;
      this._activeStar=this.selectedRatingImageSrc;
      this._rateMessageLength=100;
      this._thankyouMessageLength=100;
      this._rateTitleLength=35;
    },
    initGettersSetters: function() {
        defineSetter(this, "unselectedRatingImageSrc", function(val) {
        try{
          konymp.logger.trace("----------------------------- Setting unselectedRatingImageSrc Start", konymp.logger.FUNCTION_ENTRY);
          if (typeof(val)==='string') {
            this._inactiveStar = val;
          }
          else{
            throw{
              error: "InvalidType",
              message: "Expected string"
            };
          }
        }
        catch (e) {
          konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
          if(e.error === "InvalidType"){  
            throw e;
          }
        }
        konymp.logger.trace("-----------------------------Setting unselectedRatingImageSrc End", konymp.logger.FUNCTION_EXIT);

      });
      defineSetter(this, "selectedRatingImageSrc", function(val) {
        try{
          konymp.logger.trace("----------------------------- Setting selectedRatingImageSrc Start", konymp.logger.FUNCTION_ENTRY);
          if (typeof(val)==='string') {
            this._activeStar = val;
          }
          else{
            throw{
              error: "InvalidType",
              message: "Expected string"
            };
          }
        }
        catch (e) {
          konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
          if(e.error === "InvalidType"){  
            throw e;
          }
        }
        konymp.logger.trace("-----------------------------Setting selectedRatingImageSrc End", konymp.logger.FUNCTION_EXIT);

      });
      defineSetter(this, "rateMessage", function(val) {
        try{
          konymp.logger.trace("----------------------------- Setting rateMessage Start", konymp.logger.FUNCTION_ENTRY);
                   if (typeof(val)==='string') {
            if (val.length <= this._rateMessageLength) {
              this._rateDesc = val;
            } else {
              throw {
                error: "MessageTooLong",
                message: "Rating prompt description should be in the range of 0 to "+this._rateMessageLength
              };
            }
          }
          else {
            throw {
              error: "InvalidType",
              message: "Rating prompt description should be of type string"
            };
          }
        }
        catch (e) {
          konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
          if(e.error === "MessageTooLong" || e.error === "InvalidType"){  
            throw e;
          }
        }
        konymp.logger.trace("-----------------------------Setting rateMessage End", konymp.logger.FUNCTION_EXIT);
      });
      defineSetter(this, "isFeedbackEnabled", function(val) {
        try{
          konymp.logger.trace("----------------------------- Setting isFeedbackEnabled Start", konymp.logger.FUNCTION_ENTRY);
          if (typeof(val)==='boolean') {
            this._feedbackPopup = val;
          } else {
            throw {
              error: "InvalidType",
              message: "Invalid input type. Expecting boolean value."
            };
          }
        }
        catch (e) {
          konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
          if(e.error === "InvalidType"){  
            throw e;
          }
        }
        konymp.logger.trace("-----------------------------Setting isFeedbackEnabled End", konymp.logger.FUNCTION_EXIT);
      });
      defineSetter(this, "thankyouMessage", function(val) {
      try{
          konymp.logger.trace("----------------------------- Setting thankyouMessage Start", konymp.logger.FUNCTION_ENTRY);
          if (typeof(val)==='string') {
            if (val.length <= this._thankyouMessageLength) {
              this._completionDesc = val;
              this.view.isVisible=false;
            } else {
              throw {
                error: "MessageTooLong",
                message: "Thank you Message should be in the range of 0 to "+this._thankyouMessageLength
              };

            }
          }
          else {
            throw {
              error: "InvalidType",
              message: "Thank you Message should be of type string"
            };
          }
        }
        catch (e) {
          konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
          if(e.error === "MessageTooLong" || e.error === "InvalidType"){  
            throw e;
          }
        }
        konymp.logger.trace("-----------------------------Setting thankyouMessage End", konymp.logger.FUNCTION_EXIT);
      });
      defineSetter(this, "rateTitle", function(val) {
       try{
          konymp.logger.trace("----------------------------- Setting rateTitle Start", konymp.logger.FUNCTION_ENTRY);
          if (typeof(val)==='string') {
            if (val.length <= this._rateTitleLength) {
              this._rateTitle = val;
            } else {
              throw {
                error: "MessageTooLong",
                message: "Rating Prompt Title should be in the range of 0 to "+this._rateTitleLength
              };
            }
          }
          else {
            throw {
              error: "InvalidType",
              message: "Rating Prompt Title should be of type string"
            };

          }
        }
        catch (e) {
          konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
          if(e.error === "MessageTooLong" || e.error === "InvalidType"){  
            throw e;
          }
        }

        konymp.logger.trace("-----------------------------Setting rateTitle End", konymp.logger.FUNCTION_EXIT);
      });
    },

    /**
         * @API invokeRatingPrompt
         * @description This function invokes the Rating Prompt Component
         * @private
         */
    invokeRatingPrompt: function() {
      try {
        konymp.logger.trace("-----------------------------Start invokeRatingPrompt", konymp.logger.FUNCTION_ENTRY);
        this.showRatingScreen();
        konymp.logger.trace("-----------------------------End invokeRatingPrompt", konymp.logger.FUNCTION_ENTRY);

      } catch (e) {
        konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
      }
    },

    /**
         * @API getFeedbackText
         * @description This function is used to get the feedback text
         * @private
         */
    getFeedbackText: function() {
      try {
        konymp.logger.trace("-----------------------------Start getFeedbackText", konymp.logger.FUNCTION_ENTRY);
        if (this._feedbackText === null || this._feedbackText === undefined || this._feedbackText === "") {
          if (this._feedbackPopup === true) {
            return null;
          } else {
            throw {
              "Error": "RatingPromptComponent",
              "message": "Feedback popup is disabled"
            };
          }
        } else {
          return (this._feedbackText);
        }
        konymp.logger.trace("-----------------------------End getFeedbackText", konymp.logger.FUNCTION_EXIT);
      } catch (exception) {
        if (exception.Error == "RatingPromptComponent") {
          throw exception;
        }
      }
    },

    /**
         * @API getRatingValue
         * @description This function is used to get the rating value
         * @private
         */
    getRatingValue: function() {
      try {
        konymp.logger.trace("-----------------------------Start getRatingValue", konymp.logger.FUNCTION_ENTRY);
        return this._starSelected;
      } catch (e) {
        konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
      }
    },

    /**
         * @function showRatingScreen
         * @description This function sets the rating screen
         * @private
         */
    showRatingScreen: function() {
      try {
        konymp.logger.trace("-----------------------------Start showRatingScreen", konymp.logger.FUNCTION_ENTRY);
        this.view.isVisible=true;
        this.preAnim();
        this.arrangeWidgets();
        this.view.lblMsg.text = this._rateTitle;
        this.view.lblDesc.text = this._rateDesc;
        this.view.flxDismiss.width = "48%";
        this.view.lblDismiss.isVisible = true;
        this.view.lblOK.isVisible = false;
        this.view.lblMsg.top = "22%";
        this.currentPage = this._page.RATING;
        this.view.flxRate.forceLayout();
        this.animationStart();
        konymp.logger.trace("-----------------------------End showRatingScreen", konymp.logger.FUNCTION_EXIT);
      } catch (e) {
        konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
      }
    },
    /**
         * @function feedbackScreen
         * @description This function creates the feedback screen 
         * @private
         */
    feedbackScreen: function() {
      try {
        konymp.logger.trace("-----------------------------Start feedbackScreen", konymp.logger.FUNCTION_ENTRY);
        this.view.lblMsg.text = "Please Enter Your Feedback";
        this.view.flxStar.isVisible = false;
        this.view.lblDesc.isVisible = false;
        this.view.txtFeedback.isVisible = true;
        this.currentPage = this._page.FEEDBACK;
        konymp.logger.trace("-----------------------------End feedbackScreen", konymp.logger.FUNCTION_EXIT);
      } catch (e) {
        konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
      }
    },

    /**
         * @function thankyouScreen
         * @description This function creates the thankyou screen 
         * @private
         */
    thankyouScreen: function() {
      try {
        konymp.logger.trace("-----------------------------Start thankyouScreen", konymp.logger.FUNCTION_ENTRY);
        this.view.lblDesc.isVisible = true;
        this.view.lblMsg.top = "35%";
        this.view.lblMsg.text = "Thank You!";
        this.view.flxStar.isVisible = false;
        this.view.txtFeedback.isVisible = false;
        this._feedbackText = this.view.txtFeedback.text;
        this.view.txtFeedback.text = "";
        this.view.lblDesc.text = this._completionDesc;
        this.view.flxDismiss.width = "98%";
        this.view.lbl2.isVisible = false;
        this.view.flxSubmit.isVisible = false;
        this.view.lblOK.isVisible = true;
        this.view.lblDismiss.isVisible = false;
        this.view.imgLogo.isVisible = false;
        this.view.imgCompletion.src = this.thankyouImageSrc;
        this.view.imgCompletion.isVisible = true;
        this.view.flxRate.forceLayout();
        this.currentPage = this._page.THANKYOU;
        konymp.logger.trace("-----------------------------End thankyouScreen", konymp.logger.FUNCTION_EXIT);
      } catch (e) {
        konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
      }
    },
    /**
         * @function preAnim
         * @description This function sets the widgets to their positions initially
         * @private
         */
    preAnim: function() {
      try {
        konymp.logger.trace("-----------------------------Start preAnim", konymp.logger.FUNCTION_ENTRY);
        var trans1 = kony.ui.makeAffineTransform();
        trans1.scale(0.1, 0.1);
        var trans2 = kony.ui.makeAffineTransform();
        trans2.translate(0, 10);
        this.view.flxRate.transform = trans1;
        this.view.imgLogo.transform = trans1;
        this.view.lblMsg.transform = trans2;
        this.view.lblDesc.transform = trans2;
        this.view.flxStar.transform = trans2;
        konymp.logger.trace("-----------------------------End preAnim", konymp.logger.FUNCTION_EXIT);
      } catch (e) {
        konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
      }
    },
    /**
         * @function arrangeWidgets
         * @description This function sets the visibility of the widgets initially
         * @private
         */
    arrangeWidgets: function() {
      try {
        konymp.logger.trace("-----------------------------Start arrangeWidgets", konymp.logger.FUNCTION_ENTRY);
        this._feedbackText=null;
        this._starSelected=null;  
        this.view.imgLogo.isVisible = false;
        this.view.flxRate.isVisible = false;
        this.view.lblMsg.isVisible = false;
        this.view.lblDesc.isVisible = false;
        this.view.flxStar.isVisible = false;
        this.view.lbl1.isVisible = false;
        this.view.txtFeedback.isVisible = false;
        this.view.lbl2.isVisible = false;
        this.view.flxDismiss.isVisible = false;
        this.view.flxSubmit.isVisible = false;
        this.view.flxOverlay.isVisible = false;
        this.view.imgCompletion.isVisible = false;
        this.view.flxSubmit.setEnabled(false);
        this.view.lblSubmit.opacity=0.54;
        konymp.logger.trace("-----------------------------End arrangeWidgets", konymp.logger.FUNCTION_EXIT);
      } catch (e) {
        konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
      }

    },


    /**
         * @function animationStart
         * @description This function is invoked on invoking the Rating Prompt Component
         * @private
         */

    animationStart: function(eventobject) {
      try {
        konymp.logger.trace("-----------------------------Start animationStart", konymp.logger.FUNCTION_ENTRY);
        for (var i = 1; i <= 5; i++) {
          this.view["imgStar" + i].src = this._inactiveStar;
        }
        this.view.imgStar3.isVisible = true;
        this.view.imgStar4.isVisible = true;
        this.view.imgStar5.isVisible = true;
        this.view.flxOverlay.isVisible = true;
        this.view.flxRate.isVisible = true;
        var trans100 = kony.ui.makeAffineTransform();
        trans100.scale(1, 1);
        this.view.flxRate.animate(
          kony.ui.createAnimation({
            "100": {
              "anchorPoint": {
                "x": 0.5,
                "y": 0.5
              },
              "stepConfig": {
                "timingFunction": kony.anim.EASE
              },
              "transform": trans100,
            }
          }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": kony.anim.FILL_MODE_FORWARDS,
            "duration": 0.50
          }, {
            "animationEnd": this.animLogo.bind(this)
          });
        konymp.logger.trace("-----------------------------End animationStart", konymp.logger.FUNCTION_EXIT);
      } catch (e) {
        konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
      }
    },
    /**
         * @function animLogo
         * @description This function animates the logo that user gives and gets invoked after flex animation
         * @private
         */
    animLogo: function() {
      try {
        konymp.logger.trace("-----------------------------Start animLogo", konymp.logger.FUNCTION_ENTRY);
        this.view.imgLogo.src = this.logoImageSrc;
        var trans = kony.ui.makeAffineTransform();
        trans.scale(1, 1);
        this.view.imgLogo.animate(
          kony.ui.createAnimation({
            "100": {
              "anchorPoint": {
                "x": 0.5,
                "y": 0.5
              },
              "stepConfig": {
                "timingFunction": kony.anim.EASE
              },
              "transform": trans,
            }
          }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": kony.anim.FILL_MODE_FORWARDS,
            "duration": 0.25
          }, {
            "animationEnd": function(x, y, z) {
              this.animOtherWidgets(x);
              this.animOtherWidgets(y);
              this.animOtherWidgets(z);
            }.bind(this, this.view.lblMsg, this.view.flxStar, this.view.lblDesc)
          });
        this.view.imgLogo.isVisible = true;
        konymp.logger.trace("-----------------------------End animLogo", konymp.logger.FUNCTION_EXIT);
      } catch (e) {
        konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
      }
    },

    /**
         * @function animOtherWidgets
         * @description This function animates rest of all the the widgets and gets invoked after logo animation
         * @private
         */
    animOtherWidgets: function(widget) {
      try {
        konymp.logger.trace("-----------------------------Start animOtherWidgets", konymp.logger.FUNCTION_ENTRY);
        var trans1 = kony.ui.makeAffineTransform();
        trans1.translate(1, -10);
        widget.isVisible = true;
        widget.animate(
          kony.ui.createAnimation({
            "100": {
              "anchorPoint": {
                "x": 0.5,
                "y": 0.5
              },
              "stepConfig": {
                "timingFunction": kony.anim.EASE
              },
              "transform": trans1,
            }
          }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": kony.anim.FILL_MODE_FORWARDS,
            "duration": 0.50
          }, {
            "animationEnd": function() {}
          });
        this.view.lbl1.isVisible = true;
        this.view.lbl2.isVisible = true;
        this.view.flxDismiss.isVisible = true;
        this.view.flxSubmit.isVisible = true;
        konymp.logger.trace("-----------------------------End animOtherWidgets", konymp.logger.FUNCTION_EXIT);
      } catch (e) {
        konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
      }

    },

    /**
         * @function random
         * @description This function creates a random number for timerID
         * @private
         */
    random: function() {
      var x = Math.sin(this.seed++) * 10000;
      return x - Math.floor(x);
    },
    /**
         * @function timerTry
         * @description This function cancels the timer if the timer ID already exists
         * @private
         */
    timerTry: function() {
      try {
        konymp.logger.trace("-----------------------------Start timerTry", konymp.logger.FUNCTION_ENTRY);
        kony.timer.cancel(this._timerId);
        konymp.logger.trace("-----------------------------End timerTry", konymp.logger.FUNCTION_EXIT);
      } catch (err) {
        konymp.logger.error(JSON.stringify(err), konymp.logger.EXCEPTION);
      }
    },
    /**
         * @function starAnim
         * @description This function animates the stars while rating
         * @private
         */

    starAnim: function() {
      try {
        konymp.logger.trace("-----------------------------Start starAnim", konymp.logger.FUNCTION_ENTRY);
        if (this._indexIs !== this._starSelected) {
          this.view.flxSubmit.setEnabled(true);
          this.view.lblSubmit.opacity=1;
          this._indexIs += 1;
          var star = "imgStar" + this._indexIs;
          this.view[star].src = this._activeStar;
        }
        konymp.logger.trace("-----------------------------End starAnim", konymp.logger.FUNCTION_EXIT);
      } catch (e) {
        konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
      }
    },

    /**
         * @function setStarAnimDelay
         * @description This function sets the delay for animation while rating 
         * @private
         */
    setStarAnimDelay: function(x, y) {
      try {
        konymp.logger.trace("-----------------------------Start setStarAnimDelay", konymp.logger.FUNCTION_ENTRY);
        this._indexIs = x;
        this._starSelected = y;
        for (var i = 1; i <= 5; i++) {
          var star = "imgStar" + i;
          this.view[star].src = this._inactiveStar;
        }
        this.timerTry();
        this.view.flxSubmit.setEnabled(true);
        this.view.lblSubmit.opacity=1;
        kony.timer.schedule(this._timerId, this.starAnim.bind(this), 0.05, true);
        konymp.logger.trace("-----------------------------End setStarAnimDelay", konymp.logger.FUNCTION_EXIT);
      } catch (e) {
        konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
      }
    },

    /**
         * @function submitClick
         * @description This function is invoked when the person clicks on submit button 
         * @private
         */
    submitClick: function() {
      try {
        konymp.logger.trace("-----------------------------Start submitClick", konymp.logger.FUNCTION_ENTRY);
        this.timerTry();
        if (this._feedbackPopup === true && this.currentPage === this._page.RATING) {
          this.feedbackScreen();
        } else {
          this.thankyouScreen();
        }
        konymp.logger.trace("-----------------------------End submitClick", konymp.logger.FUNCTION_EXIT);
      } catch (e) {
        konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
      }
    },

    /**
         * @function dismissClick
         * @description This function is invoked when the person clicks on dismiss button 
         * @private
         */
    dismissClick: function() {
      try {
        konymp.logger.trace("-----------------------------Start dismissClick", konymp.logger.FUNCTION_ENTRY);
        this.timerTry();
        if (this.currentPage == this._page.THANKYOU&& this.onCompletion!==null&& this.onCompletion!==undefined&& typeof(this.onCompletion)!==undefined) {
          this.onCompletion();
        }  
        else if(this.onDismiss!==null&& this.onDismiss!==undefined&& typeof(this.onDismiss)!==undefined){
          this.onDismiss();
        }
        else if(this.currentPage == this._page.THANKYOU){
          this.view.flxOverlay.isVisible = false;
          this.view.flxRate.isVisible = false;
          this.view.isVisible=false;
        }
        else{
          this.view.flxOverlay.isVisible = false;
          this.view.flxRate.isVisible = false;
          this.view.isVisible=false;
          this._feedbackText=null;
          this._starSelected=null;
        }
        konymp.logger.trace("-----------------------------End dismissClick", konymp.logger.FUNCTION_EXIT);
      } catch (e) {
        konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
      }
    },
  }
});